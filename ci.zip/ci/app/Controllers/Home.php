<?php

namespace App\Controllers;

class Home extends BaseController
{
    
    public function index(): string
    {
        return view('home');
    }
    
    public function aboutt(): string
    {
        return view('aboutt');
    }

    public function signup(): string
    {   
        return view('signup');
    }

    public function signup_aksi(): string
    {   
        
        $db = \Config\Database::connect();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $password2 = $this->request->getPost('passwordr');

        $data = [
            'username' => $username,
            'password'  => $password
        ];

        $result = $db->table('user')->insert($data);

        $data = [
            'pesan'   => 'User telah di buat silahkan login'
        ];

        if($password != $password2) {
            $data = [
                'pesan'   => 'Password tidak sama'
            ];
        }

        return view('signup_sukses', $data);
    }

    public function login(): string
    {   
        return view('login');
    }
    




public function login_aksi(): string
    {   
        $db = \Config\Database::connect();
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $query = $db->query("SELECT * FROM user WHERE username = '".$username."' LIMIT 1");
        $row   = $query->getRowArray();

        $data = [
            'pesan'   => 'Login berhasil'
        ];
        
       
        return view('login_aksi');
        
        if($row == null) {
            $data = [
                'pesan'   => 'User tidak ditemukan'
            ];
        return view('login_salah', $data);
        } else {
            if($password != $row['password']) {
                $data = [
                    'pesan'   => 'Password salah'
                ];
                 // var_dump($row);
        return view('login_salah');
            } else {
                return redirect()->to(base_url('aboutt.html'));
            }
        }
    }
}


