<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <head>
        <title>CV/WEBSITE Duivion</title>
        <link rel="stylesheet" href="mainmenu.css">
        <link rel="icon" type="image/png" href="duivision.png"/>
    </head>
    <body>
        <div class="hero">
            <div class="navbar">
            <img src="logos.png" class="logo">
            <a href="<?=base_url()."signup" ?>">
            <button type="button">Sign Up</button>
            </a>
        </div>
        <div class="content">
            <small>Welcome To My</small>
            <h1>Zaychiku Website</h1>
            <a href="">
            <button type="button">Take a Tour</button>
            </a>

            <a href="https://zaychikuy.000webhostapp.com/login">
                <button type="button">Login</button>
            </a>
        </div>
        <div>
        </div>
        <div class="side-bar">
            <img src="menu.png" class="menu">

            <div class="social-links">
                <a href="https://www.facebook.com/Zaychiku7">
                <img src="fb.png">
                </a>
                <a href="https://www.instagram.com/elzaychikk/">
                <img src="ig.png">
                </a>
                <a href="https://www.youtube.com/channel/UCbyVIOWJAdsECLSBbb3PjQA">
                <img src="youtube+icon-1320086787359480731.png"></a>
                <a href="https://discord.gg/ctYTCbBE">
                    <img src="discord-icon-2048x2048-wooh9l0j.png">
                </a>
            </div>
            <div class="useful-links">
                <img src="info.png">
                <img src="share.png">
            </div>
        </div>

<div class="bubbles">
<img src="bubble.png">
<img src="bubble.png">
<img src="bubble.png">
<img src="bubble.png">
<img src="bubble.png">
<img src="bubble.png">
<img src="bubble.png">
</div>


        </div>
    </body>
</html>