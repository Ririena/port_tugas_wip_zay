<!-- login_salah.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Login Gagal</title>
</head>
<body>
    <h1>Login Gagal</h1>
    <p>Periksa kembali username dan password Anda.</p>
    <a href="<?php echo base_url('zaychikuy.000webhostapp.com'); ?>">Kembali ke Halaman Login</a>
</body>
</html>