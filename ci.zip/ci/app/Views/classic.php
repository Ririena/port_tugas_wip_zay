<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compactible" content="IE-edge">
  <title>Website/CV DUIVION</title>
  <link rel="icon" type="image/png" href="duivision.png"/>
  <link rel="stylesheet" href="classic.css">
<body>
 <header>
    <a href="#"class="logo">Duivion</a>

    <nav>
        <a href="mainmenu.html" class="active">Home</a>
        <a href="aboutt.html">About</a>
        <a href="classic.html">Classic Game</a>
        <a href="portofolio.html">About Us</a>
        <a href="contact_us.html">Contact</a> 
    </nav>
 </header>
 <main>
<div class="table-container">
<h2 class="table-heading">Table Pemrograman yang saya pelajari</h2>
<h1>Game Table Classic</h1>
<h1 style="text-align: center;">Random Page</h1>
<h1 style="text-align: center;">Game Table Classic</h1>
<div class="button-game">
  <a href="snake.html">
  <button type="button">Snake Game</button>
</a>
<a href="classicgame2.html">
  <button>Pong</button>
</a>
<a href="classicgame3.html">
  <button>Tetris</button>
</a>
</div>

        
 </body>
 </html>