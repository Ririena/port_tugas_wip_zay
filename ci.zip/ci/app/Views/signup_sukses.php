<p><?=$pesan ?></p>

<!DOCTYPE html>
<a href="signup">
   <button>Create Again</button>
</a>
<a href="login">
    <button>Login</button>
</a>