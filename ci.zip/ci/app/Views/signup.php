<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CV/WEBSITE DUIVION</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body>
  <div class="wrapper">
    <form action="/signup_aksi" method="post">
      <h2>Signup</h2>
        <div class="input-field">
        <input type="text" name="username" id="username" required>
        <label for="email">Username</label>
      </div>
      <div class="input-field">
        <input type="password" name="password" id="password" required>
              <label>Enter your password</label>
      </div>
      <div class="input-field">
        <input type="password" name="passwordr" id="passwordr" required>
        <label> Re Enter Your Password</label>
</div>
      <button type="submit" name="submit">Sign Up</button>
      <div class="register">
      <p>Already Have An Account? <a href="https://zaychikuy.000webhostapp.com/login">Login</a></p>
      </div>
    </form>
  </div>
  
</body>
</html>