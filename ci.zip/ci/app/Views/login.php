<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CV/WEBSITE DUIVION</title>
  <link rel="stylesheet" href="logins.css">
</head>
<body>
  <div class="wrapper">
    <form action="/login_aksi" method="post">
      <h2>Login</h2>
        <div class="input-field">
        <input type="text" name="username" id="username" required>
        <label for="email">Username</label>
      </div>
      <div class="input-field">
        <input type="password" name="password" id="password" required>
              <label>Enter your password</label>
      </div>
      <div class="forget">
        <label for="remember">
          <input type="checkbox" id="remember">
          <p>Remember me</p>
        </label>
        <a href="#">Forgot password?</a>
      </div>
      <button type="submit" name="submit">Login</button>
      <div class="register">
        <p>Don't have an account?</p> 
        <a href="https://zaychikuy.000webhostapp.com/signup">Register</a></p>
      </div>
    </form>
  </div>
    </form>
  </div>
 
  
</body>
</html>