<p><?=$pesan ?></p>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Loading Screen</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="loading-screen">
        <div class="loader"></div>
    </div>
<a href="https://zaychikuy.000webhostapp.com/aboutt.php">
    <button>Login</button>
</a>
<a href="https://zaychikuy.000webhostapp.com/">
    <button>Kembali</button>
</a>
    <div class="content">
        <!-- Your main content goes here -->
        <h1>Welcome to My Website</h1>
        <p>This is the main content of the page.</p>
    </div>
    <script>
        // Hide the loading screen after 7 seconds
        window.addEventListener('load', () => {
            setTimeout(() => {
                document.querySelector('.loading-screen').style.display = 'none';
            }, 4000);
        });
    </script>
    <script>
        if {
            const = var ()
        }
    </script>
</body>
</html>
