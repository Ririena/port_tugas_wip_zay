<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us</title>
  <link rel="stylesheet" href="style2.css">
  <link rel="icon" type="image/png" href="duivision.png"/>
</head>

<body>
  <div class="container">
    <h1>Contact Saya Apabila Ada Kesalahan/Bug Tugas Ini Di Lakukan Untuk Pak Arif</h1>
    <a href="index.html" class="floating-button" target="_blank">Back To Home</a>
    <div class="contact-info">
      <div class="info-item">
        <i class="fas fa-map-marker-alt"></i>
        <span>*Duivion Community-</span>
        <span>Bandung City </span>
        <span>-INDONESIAN</span>
      </div>
      <div class="info-item">
        <i class="fas fa-phone-alt"></i>
        <span>*Phone: +62 823-1739-9494</span>
      </div>
      <div class="info-item">
        <i class="fas fa-envelope"></i>
        <span>*Email: qaiduljaisy01@gmail.com</span>
      </div>
    </div>
    <form id="contactForm">
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" required>
      </div>

      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" required>
      </div>

      <div class="form-group">
        <label for="subject">Subject:</label>
        <input type="text" id="subject" required>
      </div>

      <div class="form-group">
        <label for="message">Message:</label>
        <textarea id="message" rows="5" required></textarea>
      </div>

      <button type="submit">Send Message</button>
    </form>
    <div id="statusMessage"></div>
  </div>

  <script src="https://kit.fontawesome.com/your-fontawesome-kit.js" crossorigin="anonymous"></script>
  <script src="script.js"></script>
</body>

</html>